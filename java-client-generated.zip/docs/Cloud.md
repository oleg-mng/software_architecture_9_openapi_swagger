# Cloud

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cloudId** | **String** |  |  [optional]
**idClient** | **String** |  | 
**OS** | [**OSEnum**](#OSEnum) | server operating system | 
**RAM** | **String** | amount of RAM | 
**CPU** | **String** | number of processor cores | 

<a name="OSEnum"></a>
## Enum: OSEnum
Name | Value
---- | -----
WINDOWS | &quot;Windows&quot;
LINUX | &quot;Linux&quot;
