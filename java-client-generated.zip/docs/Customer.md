# Customer

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**idCustomer** | **Integer** |  | 
**fio** | **String** |  | 
**hash** | **String** |  | 
