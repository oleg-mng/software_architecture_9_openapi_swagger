# IpAddressApi

All URIs are relative to *http://localhost:8080/api/v1/*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getIPaddress**](IpAddressApi.md#getIPaddress) | **GET** /ip_address/{ip_address} | method to get ip address

<a name="getIPaddress"></a>
# **getIPaddress**
> IPAddress getIPaddress(ipAddress)

method to get ip address

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.IpAddressApi;


IpAddressApi apiInstance = new IpAddressApi();
String ipAddress = "ipAddress_example"; // String | IP address
try {
    IPAddress result = apiInstance.getIPaddress(ipAddress);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling IpAddressApi#getIPaddress");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ipAddress** | **String**| IP address |

### Return type

[**IPAddress**](IPAddress.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

