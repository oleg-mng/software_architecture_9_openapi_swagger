# CustomerApi

All URIs are relative to *http://localhost:8080/api/v1/*

Method | HTTP request | Description
------------- | ------------- | -------------
[**createCustomer**](CustomerApi.md#createCustomer) | **POST** /customer | Adds a new user
[**getCustomerName**](CustomerApi.md#getCustomerName) | **GET** /customer | Name&#x27;s customer get method
[**requestServer**](CustomerApi.md#requestServer) | **HEAD** /customer | Server resource request
[**updateCustomer**](CustomerApi.md#updateCustomer) | **PUT** /customer | Update customer method

<a name="createCustomer"></a>
# **createCustomer**
> Customer createCustomer()

Adds a new user

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.CustomerApi;


CustomerApi apiInstance = new CustomerApi();
try {
    Customer result = apiInstance.createCustomer();
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling CustomerApi#createCustomer");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Customer**](Customer.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getCustomerName"></a>
# **getCustomerName**
> Customer getCustomerName()

Name&#x27;s customer get method

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.CustomerApi;


CustomerApi apiInstance = new CustomerApi();
try {
    Customer result = apiInstance.getCustomerName();
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling CustomerApi#getCustomerName");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Customer**](Customer.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="requestServer"></a>
# **requestServer**
> Customer requestServer()

Server resource request

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.CustomerApi;


CustomerApi apiInstance = new CustomerApi();
try {
    Customer result = apiInstance.requestServer();
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling CustomerApi#requestServer");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Customer**](Customer.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="updateCustomer"></a>
# **updateCustomer**
> Customer updateCustomer()

Update customer method

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.CustomerApi;


CustomerApi apiInstance = new CustomerApi();
try {
    Customer result = apiInstance.updateCustomer();
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling CustomerApi#updateCustomer");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Customer**](Customer.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

