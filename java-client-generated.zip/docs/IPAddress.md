# IPAddress

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**idAddr** | **Integer** |  | 
