package io.swagger.server.api.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.vertx.core.json.JsonObject;
import io.vertx.codegen.annotations.DataObject;
/**
 * IPAddress
 */

@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaVertXServerCodegen", date = "2023-08-15T06:43:11.466441078Z[GMT]")



public class IPAddress   {
  private Integer idAddr = null;

  public IPAddress idAddr(Integer idAddr) {
    this.idAddr = idAddr;
    return this;
  }

  /**
   * Get idAddr
   * @return idAddr
   **/
    public Integer getIdAddr() {
    return idAddr;
  }

  public void setIdAddr(Integer idAddr) {
    this.idAddr = idAddr;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    IPAddress ipAddress = (IPAddress) o;
    return Objects.equals(this.idAddr, ipAddress.idAddr);
  }

  @Override
  public int hashCode() {
    return Objects.hash(idAddr);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class IPAddress {\n");
    
    sb.append("    idAddr: ").append(toIndentedString(idAddr)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
